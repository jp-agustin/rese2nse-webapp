#!/bin/sh
# See README.txt
../../../test/setupAndRun.sh ../../../test/_internalRunPythonTests.sh $@
