$Id: README.txt 70349 2014-10-12 22:45:57Z cxh $
See package.html
