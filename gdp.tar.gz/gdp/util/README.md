This directory contains utilities useful for management.
They are standalone and do not use the gdp library.
They are not intended for release.
