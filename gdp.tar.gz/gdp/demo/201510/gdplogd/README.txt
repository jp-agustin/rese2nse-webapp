For demo purposes, we run gdplogd on 
    gdp-01.eecs.berkeley.edu
    gdp-02.eecs.berkeley.edu
    gdp-03.eecs.berkeley.edu

and some swarmboxes.

Fairly simple process: create the package using deb-pkg/package-server.sh. 
We use ver 0.3-1. 
