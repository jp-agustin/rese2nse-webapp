#!/bin/sh
./setupAndRun.sh ./_internalRunPythonTests.sh run_tests.py $@


